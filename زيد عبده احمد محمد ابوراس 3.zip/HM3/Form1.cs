﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace زيد_عبده_احمد_محمد_ابوراس_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void number1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if((e.KeyChar>57 || e.KeyChar < 48) && e.KeyChar != 8) { e.Handled = true; }
        }

        private void operation1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar !='+' && e.KeyChar != '-' && e.KeyChar != '*' && e.KeyChar != '/') && e.KeyChar != 8) { e.Handled = true; }
        }
        bool check_operation_valid()
        {
            if (operation1.TextLength == 1 && operation2.TextLength == 1) { return true; }
            else
            {
                if (operation1.TextLength > 1)
                {
                    MessageBox.Show("Error in the " + operation1.Name);
                    
                }
                else if (operation1.TextLength == 0)
                {
                    MessageBox.Show("Error empty " + operation1.Name);
                    
                }
                if (operation2.TextLength > 1)
                {
                    MessageBox.Show("Error in the " + operation2.Name);
                    
                }
                else if (operation2.TextLength == 0)
                {
                    MessageBox.Show("Error empty " + operation2.Name);
                    
                }
            }
            return false;

        }
        bool check_number_valid()
        {
            if (number1.Text != "" && number2.Text!="" && number3.Text != "") { return true; }
            else {
                if (number1.Text == "")
                {
                    MessageBox.Show("Please Enter number 1");
                }
                if (number2.Text == "")
                {
                    MessageBox.Show("Please Enter number 2");
                }
                if (number3.Text == "")
                {
                    MessageBox.Show("Please Enter number 3");
                }

            }

            return false;
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (check_operation_valid()&&check_number_valid() )
            {
                double x, y, z, s = 0;
                x = Convert.ToDouble(number1.Text);
                y = Convert.ToDouble(number2.Text);
                z = Convert.ToDouble(number3.Text);
                if(operation1.Text == "*" || operation1.Text == "/")
                {
                    if (operation1.Text == "*") { s = x * y; }
                    else { s = x / y; }

                    switch (operation2.Text)
                    {
                        case "+":s += z; break;
                        case "-": s -= z; break;
                        case "*": s *= z; break;
                        case "/": s /= z; break;
                    }

                }
                else if(operation2.Text == "*" || operation2.Text == "/")
                {
                    if (operation2.Text == "*") { s = y * z; }
                    else { s = y / z; }

                    switch (operation1.Text)
                    {
                        case "+": s = x + s; break;
                        case "-": s = x - s; break;
                        case "*": s = x * s; break;
                        case "/": s = x / s; break;
                    }
                }
                else
                {
                    switch (operation1.Text)
                    {
                        case "+": s = x + y; break;
                        case "-": s = x - y; break;                 
                    }
                    switch (operation2.Text)
                    {
                        case "+": s += z; break;
                        case "-": s -= z; ; break;
                    }

                }

                

                result.Text = Convert.ToString(s);
           

            }
            
        }//click

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
