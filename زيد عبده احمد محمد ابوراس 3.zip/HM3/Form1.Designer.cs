﻿namespace زيد_عبده_احمد_محمد_ابوراس_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.number1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.operation1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.number2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.operation2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.number3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.result = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(177, 307);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(206, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "الرقم الاول";
            // 
            // number1
            // 
            this.number1.Location = new System.Drawing.Point(35, 19);
            this.number1.Multiline = true;
            this.number1.Name = "number1";
            this.number1.Size = new System.Drawing.Size(137, 23);
            this.number1.TabIndex = 2;
            this.number1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.number1_KeyPress);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(52, 307);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 13;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // operation1
            // 
            this.operation1.Location = new System.Drawing.Point(35, 67);
            this.operation1.Multiline = true;
            this.operation1.Name = "operation1";
            this.operation1.Size = new System.Drawing.Size(137, 23);
            this.operation1.TabIndex = 4;
            this.operation1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.operation1_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(206, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "العملية";
            // 
            // number2
            // 
            this.number2.Location = new System.Drawing.Point(35, 118);
            this.number2.Multiline = true;
            this.number2.Name = "number2";
            this.number2.Size = new System.Drawing.Size(137, 23);
            this.number2.TabIndex = 6;
            this.number2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.number1_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(206, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "الرقم الثاني";
            // 
            // operation2
            // 
            this.operation2.Location = new System.Drawing.Point(35, 167);
            this.operation2.Multiline = true;
            this.operation2.Name = "operation2";
            this.operation2.Size = new System.Drawing.Size(137, 23);
            this.operation2.TabIndex = 8;
            this.operation2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.operation1_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(206, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "العملية";
            // 
            // number3
            // 
            this.number3.Location = new System.Drawing.Point(35, 215);
            this.number3.Multiline = true;
            this.number3.Name = "number3";
            this.number3.Size = new System.Drawing.Size(137, 23);
            this.number3.TabIndex = 10;
            this.number3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.number1_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(206, 218);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "الرقم الثالث";
            // 
            // result
            // 
            this.result.Location = new System.Drawing.Point(35, 260);
            this.result.Multiline = true;
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(137, 23);
            this.result.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(206, 263);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "الناتج";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 342);
            this.Controls.Add(this.result);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.number3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.operation2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.number2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.operation1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.number1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox number1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox operation1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox number2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox operation2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox number3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox result;
        private System.Windows.Forms.Label label6;
    }
}

