﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace زيد_عبده_احمد_محمد_ابوراس_3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            
            InitializeComponent();
            
            //listBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x, y, z=0;
            try
            {
                x = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الاول غير صالح");
                textBox3.Text = null;
                textBox1.Focus();
                return;
            }

            try
            {
                y = Convert.ToDouble(textBox2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الثاني غير صالح");
                textBox3.Text = null;
                textBox2.Focus();
                return;
            }
            
            switch (listBox1.SelectedItem.ToString())
            {
                case "+":z = x + y;break;
                case "-": z = x - y; break;
                case "*": z = x * y; break;
                case "/": {
                        if (y != 0) { z = x / y; break; }
                        else { MessageBox.Show("لا يمكن القسمة على صفر"); }

                        break;
                    }
            }

            textBox3.Text = z.ToString();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
            button3.BackColor = Color.Red;
            //textBox3.ReadOnly = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = null;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar > 57 || e.KeyChar < 48) && e.KeyChar != 8) { e.Handled = true; }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
