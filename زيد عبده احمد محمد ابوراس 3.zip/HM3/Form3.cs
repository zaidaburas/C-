﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace زيد_عبده_احمد_محمد_ابوراس_3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num = Convert.ToDouble(textBox1.Text),res=0;
            if (num <= 0) { MessageBox.Show("الرجاء ادخال رقم صالح"); }
            else
            {
                for(double i = num; i > 0; i--)
                {
                    res += i;
                }
                label1.Text = res.ToString();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double num = Convert.ToDouble(textBox1.Text), res = 1;
            if (num < 0) { MessageBox.Show("الرجاء ادخال رقم صالح"); }
            //else if (num == 0) { }
            else
            {

                res=Math.Sqrt(num);
               
                
                label3.Text = res.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double num = Convert.ToDouble(textBox1.Text), res = 1;
            if (num <= 0) { MessageBox.Show("الرجاء ادخال رقم صالح"); }
            else
            {
                for (double i = num; i > 0; i--)
                {
                    res *= i;
                }
                label2.Text = res.ToString();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar > 57 || e.KeyChar < 48) && e.KeyChar != 8) { e.Handled = true; }
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            button1.Enabled = button2.Enabled = button3.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "") { button1.Enabled = button2.Enabled = button3.Enabled = false; }
            else { button1.Enabled = button2.Enabled = button3.Enabled = true; }
        }
    }
}
